Edit the client.lua to suit your server 
if help is need open a ticket in my discord https://discord.gg/mMnWTrxVXm
--------------------------------------------------------------------------
TOS
You do not have the right to share / resell this script.
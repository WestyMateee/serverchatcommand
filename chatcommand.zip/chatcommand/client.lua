RegisterCommand("serverhelpmenu", function()
    -- change links below to suit your preference
   msg("Your Server: https://discord.gg/")
   msg("Your Website: www.website.com")
end, false)

function msg(text)
    -- change the [si] with your server initals, inside {}is your colour rgb so replace those if wanted
    TriggerEvent("chatMessage", "[si]", {0,128,255}, text)
end